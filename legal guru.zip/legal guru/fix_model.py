import sys
import os
import random
sys.path.append('.')

from models.echr_dataset import MOCK_ECHR_CASES, ECHR_CACHE_FILE
from models.prediction_model import train_prediction_model, predict_case_outcome, MODEL_PATH

# Add more diverse training data
print("\n===== ADDING MORE DIVERSE TRAINING DATA =====\n")

# Clear existing mock data to create a more balanced dataset
if os.path.exists(ECHR_CACHE_FILE):
    os.remove(ECHR_CACHE_FILE)
    print(f"Removed existing cache file: {ECHR_CACHE_FILE}")

# Add more diverse cases with clearer patterns
new_cases = [
    {
        "id": "001-200001",
        "title": "Detention Case 1",
        "facts": "The applicant was detained for 3 years without trial. During this period, he was not allowed to communicate with his family or legal counsel.",
        "outcome": "Violation found",
        "articles": ["Article 5"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-01",
        "case_type": "Human Rights"
    },
    {
        "id": "001-200002",
        "title": "Detention Case 2",
        "facts": "The applicant was detained for 4 years without access to legal representation. The government claimed this was necessary for national security.",
        "outcome": "Violation found",
        "articles": ["Article 5", "Article 6"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-02",
        "case_type": "Human Rights"
    },
    {
        "id": "001-200003",
        "title": "Property Case 1",
        "facts": "The applicant's property was expropriated without adequate compensation. The government claimed it was for public interest.",
        "outcome": "Violation found",
        "articles": ["Article 1 of Protocol 1"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-03",
        "case_type": "Human Rights"
    },
    {
        "id": "001-200004",
        "title": "Legal Procedure Case 1",
        "facts": "The defendant followed all required legal procedures and provided evidence of compliance with regulations.",
        "outcome": "No violation found",
        "articles": ["Article 6"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-04",
        "case_type": "Human Rights"
    },
    {
        "id": "001-200005",
        "title": "Legal Procedure Case 2",
        "facts": "The government provided evidence that the applicant had access to legal counsel throughout the proceedings.",
        "outcome": "No violation found",
        "articles": ["Article 6"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-05",
        "case_type": "Human Rights"
    },
    {
        "id": "001-200006",
        "title": "Inhuman Treatment Case 1",
        "facts": "The applicant was subjected to inhuman treatment during detention, including physical abuse and denial of medical care.",
        "outcome": "Violation found",
        "articles": ["Article 3"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-06",
        "case_type": "Human Rights"
    },
    {
        "id": "001-200007",
        "title": "Inhuman Treatment Case 2",
        "facts": "The applicant claimed inhuman treatment but the government provided evidence of proper detention conditions and medical care.",
        "outcome": "No violation found",
        "articles": ["Article 3"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2022-01-07",
        "case_type": "Human Rights"
    },
]

# Add the new cases to the mock dataset
for case in new_cases:
    MOCK_ECHR_CASES.append(case)

print(f"Added {len(new_cases)} new diverse cases to the training data")

# Force retrain the model with the new data
print("\n===== RETRAINING MODEL WITH NEW DATA =====\n")

# Remove existing model file to force complete retraining
if os.path.exists(MODEL_PATH):
    os.remove(MODEL_PATH)
    print(f"Removed existing model file: {MODEL_PATH}")

# Train a new model with all available cases
model = train_prediction_model(force_retrain=True)

# Test the improved model
print("\n===== TESTING IMPROVED MODEL =====\n")

test_cases = [
    "The applicant was detained for 5 years without trial.",
    "The defendant was found to have properly followed all procedures.",
    "The applicant claimed their property was taken without compensation.",
    "The government provided evidence that the applicant had access to legal counsel.",
    "The applicant was subjected to inhuman treatment during detention."
]

for i, test_case in enumerate(test_cases):
    result = predict_case_outcome(test_case, model)
    print(f'\nTest Case {i+1}: {test_case}')
    print(f'Prediction: {result["prediction"]}')
    print(f'Confidence: {result["confidence"]}')
    print(f'Raw Probability: {result["raw_probability"]}')

print("\n===== MODEL IMPROVEMENT COMPLETE =====\n")
print("The model should now give more diverse predictions based on the input text.")
print("Restart the backend server to apply these changes.")