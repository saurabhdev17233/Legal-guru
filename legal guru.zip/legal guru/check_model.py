import sys
import os
sys.path.append('.')

from models.echr_dataset import load_echr_dataset
from models.prediction_model import predict_case_outcome, train_prediction_model

# Check the training data
print("\n===== CHECKING TRAINING DATA =====\n")
cases = load_echr_dataset()
print(f'Number of cases: {len(cases)}')

for i, case in enumerate(cases[:5]):
    print(f'\nCase {i+1}:')
    print(f'Facts: {case["facts"][:150]}...')
    print(f'Outcome: {case["outcome"]}')

# Test the model with different inputs
print("\n===== TESTING MODEL WITH DIFFERENT INPUTS =====\n")

test_cases = [
    "The applicant was detained for 5 years without trial.",
    "The defendant was found to have properly followed all procedures.",
    "The applicant claimed their property was taken without compensation.",
    "The government provided evidence that the applicant had access to legal counsel.",
    "The applicant was subjected to inhuman treatment during detention."
]

for i, test_case in enumerate(test_cases):
    result = predict_case_outcome(test_case)
    print(f'\nTest Case {i+1}: {test_case}')
    print(f'Prediction: {result["prediction"]}')
    print(f'Confidence: {result["confidence"]}')
    print(f'Raw Probability: {result["raw_probability"]}')

# Retrain the model and test again
print("\n===== RETRAINING MODEL AND TESTING AGAIN =====\n")

# Force retrain with more mock data
model = train_prediction_model(force_retrain=True, max_cases=23)

for i, test_case in enumerate(test_cases):
    result = predict_case_outcome(test_case, model)
    print(f'\nTest Case {i+1}: {test_case}')
    print(f'Prediction: {result["prediction"]}')
    print(f'Confidence: {result["confidence"]}')
    print(f'Raw Probability: {result["raw_probability"]}')