import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// Make Three.js and React Three Fiber globals available to React components
if (window.THREE) {
  window.three = window.THREE;
}

if (window.R3F) {
  window.ReactThreeFiber = window.R3F;
}

if (window.DREI) {
  window.drei = window.DREI;
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();