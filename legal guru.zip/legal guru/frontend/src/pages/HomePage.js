import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import EditNoteIcon from '@mui/icons-material/EditNote';
import BalanceIcon from '@mui/icons-material/Balance';
import Container from '@mui/material/Container';

const HomePage = () => {
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4, textAlign: 'center' }}>
        <Typography variant="h2" component="h1" gutterBottom>
          Welcome to Legal Guru
        </Typography>
        <Typography variant="h5" component="h2" gutterBottom color="text.secondary">
          AI-Powered Case Outcome Prediction System
        </Typography>
        <Box sx={{ mt: 4, mb: 6 }}>
          <Typography variant="body1" paragraph>
            Legal Guru helps legal professionals predict case outcomes by analyzing case details and comparing them with historical data.
            Our AI-powered system provides evidence-based predictions and strategic recommendations to enhance your legal practice.
          </Typography>
        </Box>

        <Grid container spacing={4} justifyContent="center">
          <Grid item xs={12} sm={6} md={4}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                  <UploadFileIcon fontSize="large" color="primary" />
                </Box>
                <Typography gutterBottom variant="h5" component="h2">
                  Upload Case Document
                </Typography>
                <Typography>
                  Upload your case documents (PDF or DOCX) and let our system analyze them to predict potential outcomes.
                </Typography>
              </CardContent>
              <CardActions>
                <Button
                  fullWidth
                  variant="contained"
                  component={RouterLink}
                  to="/upload"
                >
                  Upload Document
                </Button>
              </CardActions>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                  <EditNoteIcon fontSize="large" color="primary" />
                </Box>
                <Typography gutterBottom variant="h5" component="h2">
                  Enter Case Details
                </Typography>
                <Typography>
                  Manually enter your case details through our structured form for a customized prediction.
                </Typography>
              </CardContent>
              <CardActions>
                <Button
                  fullWidth
                  variant="contained"
                  component={RouterLink}
                  to="/form"
                >
                  Enter Details
                </Button>
              </CardActions>
            </Card>
          </Grid>
        </Grid>

        <Box sx={{ mt: 6, mb: 4 }}>
          <Typography variant="h4" gutterBottom>
            How It Works
          </Typography>
          <Grid container spacing={2} justifyContent="center">
            <Grid item xs={12} md={8}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box sx={{ mr: 2, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 40, height: 40, borderRadius: '50%', bgcolor: 'primary.main', color: 'white' }}>
                  1
                </Box>
                <Typography variant="h6">Upload your case document or enter case details</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box sx={{ mr: 2, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 40, height: 40, borderRadius: '50%', bgcolor: 'primary.main', color: 'white' }}>
                  2
                </Box>
                <Typography variant="h6">Our AI analyzes your case and compares it with similar historical cases</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box sx={{ mr: 2, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 40, height: 40, borderRadius: '50%', bgcolor: 'primary.main', color: 'white' }}>
                  3
                </Box>
                <Typography variant="h6">Receive a detailed prediction with supporting evidence and strategic recommendations</Typography>
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Container>
  );
};

export default HomePage;