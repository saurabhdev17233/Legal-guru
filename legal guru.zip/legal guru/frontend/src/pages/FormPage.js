import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import axios from 'axios';

const caseTypes = [
  'Breach of Contract',
  'Negligence',
  'Personal Injury',
  'Intellectual Property',
  'Employment',
  'Real Estate',
  'Family Law',
  'Criminal',
  'Human Rights',
  'Other',
];

const jurisdictions = [
  'Federal',
  'State',
  'Local',
  'ECHR (European Court of Human Rights)',
  'International',
  'Other',
];

const FormPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    caseTitle: '',
    caseType: '',
    caseDescription: '',
    plaintiff: '',
    defendant: '',
    filingDate: '',
    jurisdiction: '',
    claimAmount: '',
    keyFacts: '',
    relevantLaws: '',
    isHumanRightsCase: false,
    echrArticles: '',
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
    
    // Auto-select Human Rights case type when ECHR jurisdiction is selected
    if (name === 'jurisdiction' && value.includes('ECHR')) {
      setFormData(prev => ({
        ...prev,
        caseType: 'Human Rights',
        isHumanRightsCase: true,
      }));
    }
    
    // Auto-select ECHR jurisdiction when Human Rights case type is selected
    if (name === 'caseType' && value === 'Human Rights') {
      setFormData(prev => ({
        ...prev,
        jurisdiction: prev.jurisdiction || 'ECHR (European Court of Human Rights)',
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Validate required fields
    if (!formData.caseTitle || !formData.caseType || !formData.caseDescription) {
      setError('Please fill in all required fields');
      setLoading(false);
      return;
    }

    try {
      // Send form data to backend
      const response = await axios.post('http://127.0.0.1:5000/api/form', {
        facts: formData.caseDescription,
        citations: formData.relevantLaws ? formData.relevantLaws.split('\n') : [],
        jurisdiction: formData.jurisdiction
      });
      
      // Navigate to dashboard with the case ID
      setTimeout(() => {
        navigate(`/dashboard/${response.data.id}`);
      }, 1000);
    } catch (err) {
      setError('Error submitting form. Please try again.');
      console.error('Form submission error:', err);
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Enter Case Details
        </Typography>
        <Typography variant="body1" paragraph align="center">
          Fill in the details of your legal case for analysis and prediction.
        </Typography>

        <Paper elevation={3} sx={{ p: 4, mt: 4, mb: 4 }}>
          {error && (
            <Alert severity="error" sx={{ width: '100%', mb: 2 }}>
              {error}
            </Alert>
          )}

          <Box component="form" onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Case Title"
                  name="caseTitle"
                  value={formData.caseTitle}
                  onChange={handleChange}
                  variant="outlined"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <FormControl fullWidth required>
                  <InputLabel id="case-type-label">Case Type</InputLabel>
                  <Select
                    labelId="case-type-label"
                    name="caseType"
                    value={formData.caseType}
                    onChange={handleChange}
                    label="Case Type"
                  >
                    {caseTypes.map((type) => (
                      <MenuItem key={type} value={type}>
                        {type}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Filing Date"
                  name="filingDate"
                  type="date"
                  value={formData.filingDate}
                  onChange={handleChange}
                  InputLabelProps={{ shrink: true }}
                  variant="outlined"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Plaintiff/Claimant"
                  name="plaintiff"
                  value={formData.plaintiff}
                  onChange={handleChange}
                  variant="outlined"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Defendant/Respondent"
                  name="defendant"
                  value={formData.defendant}
                  onChange={handleChange}
                  variant="outlined"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="jurisdiction-label">Jurisdiction</InputLabel>
                  <Select
                    labelId="jurisdiction-label"
                    name="jurisdiction"
                    value={formData.jurisdiction}
                    onChange={handleChange}
                    label="Jurisdiction"
                  >
                    {jurisdictions.map((jurisdiction) => (
                      <MenuItem key={jurisdiction} value={jurisdiction}>
                        {jurisdiction}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Claim Amount ($)"
                  name="claimAmount"
                  type="number"
                  value={formData.claimAmount}
                  onChange={handleChange}
                  variant="outlined"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Case Description"
                  name="caseDescription"
                  value={formData.caseDescription}
                  onChange={handleChange}
                  multiline
                  rows={4}
                  variant="outlined"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Key Facts"
                  name="keyFacts"
                  value={formData.keyFacts}
                  onChange={handleChange}
                  multiline
                  rows={3}
                  variant="outlined"
                  placeholder="Enter key facts separated by new lines"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Relevant Laws or Precedents"
                  name="relevantLaws"
                  value={formData.relevantLaws}
                  onChange={handleChange}
                  multiline
                  rows={3}
                  variant="outlined"
                  placeholder="Enter relevant laws or precedents separated by new lines"
                />
              </Grid>
              
              {(formData.jurisdiction.includes('ECHR') || formData.caseType === 'Human Rights') && (
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="ECHR Articles (if applicable)"
                    name="echrArticles"
                    value={formData.echrArticles}
                    onChange={handleChange}
                    variant="outlined"
                    placeholder="E.g., Article 6, Article 8"
                    helperText="Enter the ECHR articles relevant to your case"
                  />
                </Grid>
              )}

              <Grid item xs={12} sx={{ mt: 2, textAlign: 'center' }}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                  sx={{ minWidth: 200 }}
                >
                  {loading ? (
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <CircularProgress size={24} sx={{ mr: 1 }} />
                      Processing...
                    </Box>
                  ) : (
                    'Submit and Analyze'
                  )}
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Paper>

        <Box sx={{ mt: 2, textAlign: 'center' }}>
          <Typography variant="body2" color="text.secondary">
            Your case information will be stored locally on your PC and will not be shared with any third parties.
          </Typography>
        </Box>
      </Box>
    </Container>
  );
};

export default FormPage;