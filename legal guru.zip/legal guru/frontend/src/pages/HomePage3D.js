import React, { Suspense, useRef } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import EditNoteIcon from '@mui/icons-material/EditNote';
import Container from '@mui/material/Container';
import { styled } from '@mui/material/styles';
import { motion } from 'framer-motion';

// Import 3D components
import Scene3D from '../components/3d/Scene3D';
import ScalesOfJustice from '../components/3d/ScalesOfJustice';
import Background3D from '../components/3d/Background3D';

// Styled components for enhanced UI
const HeroSection = styled(Box)(({ theme }) => ({
  position: 'relative',
  height: '80vh',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  color: '#fff',
  textAlign: 'center',
  overflow: 'hidden',
  padding: theme.spacing(4),
  background: 'linear-gradient(135deg, rgba(25, 118, 210, 0.8) 0%, rgba(41, 121, 255, 0.8) 100%)',
  borderRadius: theme.spacing(2),
  boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)',
  marginBottom: theme.spacing(8),
}));

const GlassCard = styled(Card)(({ theme }) => ({
  background: 'rgba(255, 255, 255, 0.8)',
  backdropFilter: 'blur(10px)',
  borderRadius: theme.spacing(2),
  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
  transition: 'all 0.3s ease',
  overflow: 'hidden',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  '&:hover': {
    transform: 'translateY(-10px)',
    boxShadow: '0 15px 35px rgba(0, 0, 0, 0.2)',
  },
}));

const StyledButton = styled(Button)(({ theme }) => ({
  borderRadius: theme.spacing(5),
  padding: theme.spacing(1, 4),
  fontWeight: 'bold',
  textTransform: 'none',
  fontSize: '1rem',
  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
  transition: 'all 0.3s ease',
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.3)',
  },
}));

const ScalesContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '400px',
  position: 'relative',
  marginBottom: theme.spacing(4),
}));

const StepBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginBottom: theme.spacing(3),
  padding: theme.spacing(2),
  borderRadius: theme.spacing(2),
  background: 'rgba(255, 255, 255, 0.9)',
  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)',
  transition: 'all 0.3s ease',
  '&:hover': {
    transform: 'translateX(10px)',
    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.15)',
  },
}));

const StepNumber = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 50,
  height: 50,
  borderRadius: '50%',
  background: 'linear-gradient(135deg, #1976d2 0%, #2979ff 100%)',
  color: 'white',
  fontWeight: 'bold',
  fontSize: '1.5rem',
  marginRight: theme.spacing(2),
  boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)',
}));

const HomePage3D = () => {
  return (
    <>
      {/* 3D Background */}
      <Background3D height="200vh" />
      
      {/* Hero Section */}
      <HeroSection>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Typography 
            variant="h1" 
            component="h1" 
            gutterBottom
            sx={{ 
              fontWeight: 900, 
              fontSize: { xs: '2.5rem', md: '4rem' },
              textShadow: '0 2px 10px rgba(0, 0, 0, 0.3)',
              fontFamily: '"Cinzel", serif',
              letterSpacing: 3,
            }}
          >
            LEGAL GURU
          </Typography>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <Typography 
            variant="h5" 
            component="h2" 
            gutterBottom 
            sx={{ 
              fontWeight: 500,
              marginBottom: 4,
              textShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
              maxWidth: '800px',
            }}
          >
            AI-Powered Case Outcome Prediction System with Advanced Legal Analysis
          </Typography>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <Grid container spacing={3} justifyContent="center" sx={{ mt: 4, mb: 2 }}>
            <Grid item xs={12} sm={6} md={4}>
              <StyledButton
                fullWidth
                variant="contained"
                size="large"
                component={RouterLink}
                to="/upload"
                startIcon={<UploadFileIcon />}
                sx={{ 
                  background: 'linear-gradient(45deg, #ff9800 30%, #ff5722 90%)',
                  height: 60,
                }}
              >
                Upload Case Document
              </StyledButton>
            </Grid>
            
            <Grid item xs={12} sm={6} md={4}>
              <StyledButton
                fullWidth
                variant="contained"
                size="large"
                component={RouterLink}
                to="/form"
                startIcon={<EditNoteIcon />}
                sx={{ 
                  background: 'linear-gradient(45deg, #2196f3 30%, #1976d2 90%)',
                  height: 60,
                }}
              >
                Enter Case Details
              </StyledButton>
            </Grid>
          </Grid>
        </motion.div>
      </HeroSection>
      
      {/* 3D Scales of Justice */}
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
        >
          <Typography 
            variant="h3" 
            component="h2" 
            align="center" 
            gutterBottom
            sx={{ 
              fontWeight: 700, 
              mb: 6,
              fontFamily: '"Cinzel", serif',
              color: '#1a237e',
            }}
          >
            JUSTICE THROUGH TECHNOLOGY
          </Typography>
        </motion.div>
        
        <ScalesContainer>
          <Scene3D cameraPosition={[0, 0, 10]} height="400px">
            <ScalesOfJustice position={[0, 0, 0]} scale={1.5} />
          </Scene3D>
        </ScalesContainer>
        
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Typography 
            variant="body1" 
            paragraph 
            align="center"
            sx={{ 
              fontSize: '1.2rem', 
              maxWidth: '800px', 
              margin: '0 auto',
              mb: 8,
            }}
          >
            Legal Guru helps legal professionals predict case outcomes by analyzing case details and comparing them with historical data.
            Our AI-powered system provides evidence-based predictions and strategic recommendations to enhance your legal practice.
          </Typography>
        </motion.div>
        
        {/* Feature Cards */}
        <Grid container spacing={4} justifyContent="center" sx={{ mb: 8 }}>
          <Grid item xs={12} sm={6} md={4}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <GlassCard>
                <CardContent sx={{ flexGrow: 1, p: 4 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
                    <UploadFileIcon sx={{ fontSize: 60, color: '#ff9800' }} />
                  </Box>
                  <Typography gutterBottom variant="h5" component="h2" align="center" sx={{ fontWeight: 700 }}>
                    Document Analysis
                  </Typography>
                  <Typography variant="body1" sx={{ mb: 3 }}>
                    Upload your case documents (PDF or DOCX) and let our system analyze them to predict potential outcomes with advanced AI technology.
                  </Typography>
                </CardContent>
                <CardActions sx={{ p: 3, pt: 0 }}>
                  <Button
                    fullWidth
                    variant="outlined"
                    component={RouterLink}
                    to="/upload"
                    sx={{ borderRadius: 8 }}
                  >
                    Upload Document
                  </Button>
                </CardActions>
              </GlassCard>
            </motion.div>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <GlassCard>
                <CardContent sx={{ flexGrow: 1, p: 4 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
                    <EditNoteIcon sx={{ fontSize: 60, color: '#2196f3' }} />
                  </Box>
                  <Typography gutterBottom variant="h5" component="h2" align="center" sx={{ fontWeight: 700 }}>
                    Manual Entry
                  </Typography>
                  <Typography variant="body1" sx={{ mb: 3 }}>
                    Manually enter your case details through our structured form for a customized prediction with detailed analysis and recommendations.
                  </Typography>
                </CardContent>
                <CardActions sx={{ p: 3, pt: 0 }}>
                  <Button
                    fullWidth
                    variant="outlined"
                    component={RouterLink}
                    to="/form"
                    sx={{ borderRadius: 8 }}
                  >
                    Enter Details
                  </Button>
                </CardActions>
              </GlassCard>
            </motion.div>
          </Grid>
        </Grid>
        
        {/* How It Works Section */}
        <Box sx={{ mt: 8, mb: 10 }}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Typography 
              variant="h3" 
              gutterBottom 
              align="center"
              sx={{ 
                fontWeight: 700, 
                mb: 6,
                fontFamily: '"Cinzel", serif',
                color: '#1a237e',
              }}
            >
              HOW IT WORKS
            </Typography>
          </motion.div>
          
          <Grid container spacing={2} justifyContent="center">
            <Grid item xs={12} md={8}>
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <StepBox>
                  <StepNumber>1</StepNumber>
                  <Typography variant="h6">Upload your case document or enter case details</Typography>
                </StepBox>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <StepBox>
                  <StepNumber>2</StepNumber>
                  <Typography variant="h6">Our AI analyzes your case and compares it with similar historical cases</Typography>
                </StepBox>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                <StepBox>
                  <StepNumber>3</StepNumber>
                  <Typography variant="h6">Receive a detailed prediction with supporting evidence and strategic recommendations</Typography>
                </StepBox>
              </motion.div>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </>
  );
};

export default HomePage3D;