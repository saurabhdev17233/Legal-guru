import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Chip from '@mui/material/Chip';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import GavelIcon from '@mui/icons-material/Gavel';
import DescriptionIcon from '@mui/icons-material/Description';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import BalanceIcon from '@mui/icons-material/Balance';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import PsychologyIcon from '@mui/icons-material/Psychology';
import AssignmentIcon from '@mui/icons-material/Assignment';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import axios from 'axios';

// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const DashboardPage = () => {
  const { caseId } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [caseData, setCaseData] = useState(null);

  useEffect(() => {
    const fetchCaseData = async () => {
      try {
        // Use the new endpoint to get case data by ID
        const response = await axios.get(`http://127.0.0.1:5000/api/case/${caseId}`);
        
        // Set the case data from the response
        setCaseData(response.data);
        setLoading(false);
      } catch (err) {
        setError('Error loading case data. Please try again.');
        console.error('Case data loading error:', err);
        setLoading(false);
      }
    };

    // Fetch the case data
    fetchCaseData();
  }, [caseId]);

  // Prepare chart data
  const getChartData = (winProbability) => {
    return {
      labels: ['Win Probability', 'Loss Probability'],
      datasets: [
        {
          data: [winProbability, 100 - winProbability],
          backgroundColor: ['#4caf50', '#f44336'],
          borderColor: ['#388e3c', '#d32f2f'],
          borderWidth: 1,
        },
      ],
    };
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
      },
    },
  };

  if (loading) {
    return (
      <Container maxWidth="lg">
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '60vh',
          }}
        >
          <CircularProgress size={60} />
          <Typography variant="h6" sx={{ mt: 2 }}>
            Analyzing case data and generating predictions...
          </Typography>
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg">
        <Box sx={{ my: 4 }}>
          <Alert severity="error" sx={{ width: '100%', mb: 2 }}>
            {error}
          </Alert>
          <Button variant="contained" color="primary" href="/">
            Return to Home
          </Button>
        </Box>
      </Container>
    );
  }

  // Mock data for demonstration
  const mockCaseData = {
    caseId: caseId,
    caseTitle: 'Doe v. ACME Corporation',
    caseType: 'Breach of Contract',
    caseDescription: 'Breach of contract case involving failure to deliver products as specified in the agreement.',
    plaintiff: 'Jane Doe',
    defendant: 'ACME Corporation',
    filingDate: '2023-06-01',
    jurisdiction: 'Northern District of California',
    echrArticles: '',  // ECHR specific field
    prediction: {
      winProbability: 72,
      outcome: 'Likely to win',
      confidenceLevel: 'High',
    },
    similarCases: [
      {
        id: 'SC001',
        title: 'Smith v. XYZ Corp',
        outcome: 'Won',
        similarity: 85,
        jurisdiction: 'Federal',
        keyPoints: 'Similar breach of contract with defective products. Court ruled in favor of plaintiff due to clear evidence of product defects.',
      },
      {
        id: 'SC002',
        title: 'Johnson v. ABC Inc',
        outcome: 'Won',
        similarity: 78,
        jurisdiction: 'State',
        keyPoints: 'Breach of contract with misrepresentation of product quality. Plaintiff awarded damages for lost profits.',
      },
      {
        id: 'SC003',
        title: 'Williams v. DEF Ltd',
        outcome: 'Lost',
        similarity: 65,
        jurisdiction: 'Federal',
        keyPoints: 'Similar case but plaintiff failed to provide timely notice of defects as required by contract.',
      },
      {
        id: 'ECHR001',
        title: 'ECHR Case #42',
        outcome: 'Violation found',
        similarity: 72,
        jurisdiction: 'ECHR',
        keyPoints: 'European Court of Human Rights case involving Article 6 (right to fair trial). Court found violation due to excessive length of proceedings.',
        echrArticles: ['Article 6']
      },
    ],
    keyFactors: [
      {
        factor: 'Clear contract terms',
        impact: 'Positive',
        description: 'The contract clearly specifies quality requirements and delivery terms.',
      },
      {
        factor: 'Documented defects',
        impact: 'Positive',
        description: 'Evidence shows 42% defect rate, well above the 0.1% specified in the contract.',
      },
      {
        factor: 'Timely notification',
        impact: 'Positive',
        description: 'Plaintiff notified defendant of defects within the timeframe specified in the contract.',
      },
      {
        factor: 'Prior representations',
        impact: 'Positive',
        description: 'Defendant made representations about product quality that were demonstrably false.',
      },
      {
        factor: 'Partial payment',
        impact: 'Neutral',
        description: 'Plaintiff made partial payment, which may affect the calculation of damages.',
      },
    ],
    strategicRecommendations: [
      'Focus on the clear breach of quality specifications in the contract',
      'Emphasize the timely notification of defects as per contract terms',
      'Present evidence of false representations made by the defendant',
      'Quantify lost profits with detailed financial documentation',
      'Consider settlement negotiations with a minimum target of $400,000',
      'Prepare expert testimony on industry standards for product quality',
    ],
    riskFactors: [
      'Defendant may argue that some defects were due to plaintiff\'s handling',
      'Contract may have limitation of liability clauses that could cap damages',
      'Proving exact amount of lost profits may be challenging',
    ],
  };

  // Use actual data from the backend instead of mock data
  const displayData = caseData || mockCaseData;
  
  // Map the API response to the expected format
  let prediction, similarCases, keyFactors, strategicRecommendations, riskFactors;
  
  if (caseData) {
    // Handle actual API response
    prediction = {
      winProbability: Math.round(caseData.prediction.confidence * 100),
      outcome: caseData.prediction.prediction,
      confidenceLevel: caseData.prediction.confidence > 0.7 ? 'High' : caseData.prediction.confidence > 0.5 ? 'Medium' : 'Low'
    };
    
    similarCases = caseData.similar_cases ? caseData.similar_cases.map(sc => ({
      id: sc.id || `SC${Math.random().toString(36).substr(2, 5)}`,
      title: sc.title || 'Unknown Case',
      outcome: sc.outcome || 'Unknown',
      similarity: Math.round((sc.similarity || 0.5) * 100),
      jurisdiction: sc.jurisdiction || 'Unknown',
      keyPoints: sc.facts || ''
    })) : [];
    
    // Create key factors from case_info
    keyFactors = [];
    if (caseData.case_info) {
      if (caseData.case_info.jurisdiction) {
        keyFactors.push({
          factor: 'Jurisdiction',
          impact: 'Neutral',
          description: `Case is under ${caseData.case_info.jurisdiction} jurisdiction`
        });
      }
      
      if (caseData.case_info.citations && caseData.case_info.citations.length > 0) {
        keyFactors.push({
          factor: 'Citations',
          impact: 'Positive',
          description: `Relevant citations: ${caseData.case_info.citations.join(', ')}`
        });
      }
      
      if (caseData.case_info.facts) {
        keyFactors.push({
          factor: 'Case Facts',
          impact: 'Neutral',
          description: caseData.case_info.facts.substring(0, 100) + '...'
        });
      }
    }
    
    // Use strategies from API
    strategicRecommendations = caseData.strategies || [];
    
    // Create risk factors
    riskFactors = [
      'Case outcome predictions are based on historical data and may not reflect all nuances of your specific case',
      'Legal precedents can change over time',
      'Jurisdiction-specific rules may apply'
    ];
  } else {
    // Use mock data
    prediction = displayData.prediction;
    similarCases = displayData.similarCases;
    keyFactors = displayData.keyFactors;
    strategicRecommendations = displayData.strategicRecommendations;
    riskFactors = displayData.riskFactors;
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Case Analysis Dashboard
        </Typography>

        {/* Case Summary */}
        <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={8}>
              <Typography variant="h5" gutterBottom>
                {caseData ? caseData.filename : displayData.caseTitle}
              </Typography>
              {!caseData && (
                <>
                  <Typography variant="body1" paragraph>
                    <strong>Case Type:</strong> {displayData.caseType}
                  </Typography>
                  <Typography variant="body1" paragraph>
                    <strong>Description:</strong> {displayData.caseDescription}
                  </Typography>
                  <Typography variant="body1">
                    <strong>Parties:</strong> {displayData.plaintiff} v. {displayData.defendant}
                  </Typography>
                </>
              )}
              {caseData && caseData.case_info && caseData.case_info.facts && (
                <Typography variant="body1" paragraph>
                  <strong>Facts:</strong> {caseData.case_info.facts.substring(0, 200)}...
                </Typography>
              )}
              <Typography variant="body1">
                <strong>Jurisdiction:</strong> {caseData ? (caseData.case_info ? caseData.case_info.jurisdiction : 'Unknown') : displayData.jurisdiction}
              </Typography>
              {!caseData && (
                <Typography variant="body1">
                  <strong>Filing Date:</strong> {displayData.filingDate}
                </Typography>
              )}
              {displayData.jurisdiction && displayData.jurisdiction.includes('ECHR') && displayData.echrArticles && (
                <Typography variant="body1">
                  <strong>ECHR Articles:</strong> {displayData.echrArticles}
                </Typography>
              )}
            </Grid>
            <Grid item xs={12} md={4}>
              <Box sx={{ height: 200, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Doughnut data={getChartData(prediction.winProbability)} options={chartOptions} />
              </Box>
            </Grid>
          </Grid>
        </Paper>

        <Grid container spacing={4}>
          {/* Prediction Summary */}
          <Grid item xs={12} md={6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <BalanceIcon color="primary" sx={{ mr: 1 }} />
                  <Typography variant="h5">Outcome Prediction</Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Typography variant="h3" color="primary" sx={{ mr: 1 }}>
                    {prediction.winProbability}%
                  </Typography>
                  <Typography variant="h6">Win Probability</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Typography variant="body1">
                    <strong>Predicted Outcome:</strong> {prediction.outcome}
                  </Typography>
                  <Chip
                    label={prediction.confidenceLevel}
                    color={prediction.confidenceLevel === 'High' ? 'success' : 'warning'}
                    size="small"
                    sx={{ ml: 1 }}
                  />
                </Box>
                <Typography variant="body1" paragraph>
                  Based on our analysis of similar cases and the specific factors in your case, we predict a favorable outcome with a {prediction.winProbability}% probability of success.
                </Typography>
              </CardContent>
            </Card>
          </Grid>

          {/* Key Factors */}
          <Grid item xs={12} md={6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <GavelIcon color="primary" sx={{ mr: 1 }} />
                  <Typography variant="h5">Key Factors</Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <List dense>
                  {keyFactors.map((factor, index) => (
                    <ListItem key={index}>
                      <ListItemIcon>
                        {factor.impact === 'Positive' ? (
                          <CheckCircleIcon color="success" />
                        ) : factor.impact === 'Negative' ? (
                          <WarningIcon color="error" />
                        ) : (
                          <BalanceIcon color="action" />
                        )}
                      </ListItemIcon>
                      <ListItemText
                        primary={factor.factor}
                        secondary={factor.description}
                      />
                    </ListItem>
                  ))}
                </List>
              </CardContent>
            </Card>
          </Grid>

          {/* Similar Cases */}
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <DescriptionIcon color="primary" sx={{ mr: 1 }} />
                  <Typography variant="h5">Similar Cases</Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Grid container spacing={3}>
                  {similarCases.map((similarCase, index) => (
                    <Grid item xs={12} md={4} key={index}>
                      <Paper elevation={2} sx={{ p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                          {similarCase.title}
                        </Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Chip
                            label={similarCase.outcome}
                            color={
                              similarCase.outcome === 'Won' || similarCase.outcome === 'Violation found' 
                                ? 'success' 
                                : similarCase.outcome === 'Lost' || similarCase.outcome === 'No violation found' 
                                  ? 'error' 
                                  : 'default'
                            }
                            size="small"
                            sx={{ mr: 1 }}
                          />
                          <Typography variant="body2">
                            Similarity: {similarCase.similarity}%
                          </Typography>
                        </Box>
                        {similarCase.jurisdiction && (
                          <Typography variant="body2" sx={{ mb: 1 }}>
                            <strong>Jurisdiction:</strong> {similarCase.jurisdiction}
                          </Typography>
                        )}
                        {similarCase.echrArticles && similarCase.echrArticles.length > 0 && (
                          <Typography variant="body2" sx={{ mb: 1 }}>
                            <strong>ECHR Articles:</strong> {similarCase.echrArticles.join(', ')}
                          </Typography>
                        )}
                        <Typography variant="body2">{similarCase.keyPoints}</Typography>
                      </Paper>
                    </Grid>
                  ))}
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          {/* Strategic Recommendations */}
          <Grid item xs={12} md={6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <LightbulbIcon color="primary" sx={{ mr: 1 }} />
                  <Typography variant="h5">Strategic Recommendations</Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <List dense>
                  {strategicRecommendations.map((recommendation, index) => (
                    <ListItem key={index}>
                      <ListItemIcon>
                        <TipsAndUpdatesIcon color="primary" />
                      </ListItemIcon>
                      <ListItemText primary={recommendation} />
                    </ListItem>
                  ))}
                </List>
              </CardContent>
            </Card>
          </Grid>

          {/* Risk Factors */}
          <Grid item xs={12} md={6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <WarningIcon color="warning" sx={{ mr: 1 }} />
                  <Typography variant="h5">Risk Factors</Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <List dense>
                  {riskFactors.map((risk, index) => (
                    <ListItem key={index}>
                      <ListItemIcon>
                        <WarningIcon color="warning" />
                      </ListItemIcon>
                      <ListItemText primary={risk} />
                    </ListItem>
                  ))}
                </List>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Enhanced Analysis (Groq AI) */}
          {caseData && caseData.enhanced_analysis && (
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <PsychologyIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h5">Enhanced AI Analysis</Typography>
                    <Chip label="" color="secondary" size="small" sx={{ ml: 2 }} />
                  </Box>
                  <Divider sx={{ mb: 2 }} />
                  
                  <Grid container spacing={3}>
                    {/* Legal Issues */}
                    {caseData.enhanced_analysis.issues && (
                      <Grid item xs={12} md={6}>
                        <Paper elevation={2} sx={{ p: 2 }}>
                          <Typography variant="h6" gutterBottom>
                            Key Legal Issues
                          </Typography>
                          <List dense>
                            {Array.isArray(caseData.enhanced_analysis.issues) ? (
                              caseData.enhanced_analysis.issues.map((issue, index) => (
                                <ListItem key={index}>
                                  <ListItemIcon>
                                    <AssignmentIcon color="primary" />
                                  </ListItemIcon>
                                  <ListItemText primary={issue} />
                                </ListItem>
                              ))
                            ) : (
                              <ListItem>
                                <ListItemIcon>
                                  <AssignmentIcon color="primary" />
                                </ListItemIcon>
                                <ListItemText primary={caseData.enhanced_analysis.issues} />
                              </ListItem>
                            )}
                          </List>
                        </Paper>
                      </Grid>
                    )}
                    
                    {/* Claims and Defenses */}
                    {(caseData.enhanced_analysis.claims || caseData.enhanced_analysis.defenses) && (
                      <Grid item xs={12} md={6}>
                        <Paper elevation={2} sx={{ p: 2 }}>
                          <Typography variant="h6" gutterBottom>
                            Claims & Defenses
                          </Typography>
                          
                          {caseData.enhanced_analysis.claims && (
                            <>
                              <Typography variant="subtitle1" gutterBottom>
                                Potential Claims:
                              </Typography>
                              <List dense>
                                {Array.isArray(caseData.enhanced_analysis.claims) ? (
                                  caseData.enhanced_analysis.claims.map((claim, index) => (
                                    <ListItem key={index}>
                                      <ListItemIcon>
                                        <CheckCircleIcon color="success" />
                                      </ListItemIcon>
                                      <ListItemText primary={claim} />
                                    </ListItem>
                                  ))
                                ) : (
                                  <ListItem>
                                    <ListItemIcon>
                                      <CheckCircleIcon color="success" />
                                    </ListItemIcon>
                                    <ListItemText primary={caseData.enhanced_analysis.claims} />
                                  </ListItem>
                                )}
                              </List>
                            </>
                          )}
                          
                          {caseData.enhanced_analysis.defenses && (
                            <>
                              <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
                                Potential Defenses:
                              </Typography>
                              <List dense>
                                {Array.isArray(caseData.enhanced_analysis.defenses) ? (
                                  caseData.enhanced_analysis.defenses.map((defense, index) => (
                                    <ListItem key={index}>
                                      <ListItemIcon>
                                        <WarningIcon color="warning" />
                                      </ListItemIcon>
                                      <ListItemText primary={defense} />
                                    </ListItem>
                                  ))
                                ) : (
                                  <ListItem>
                                    <ListItemIcon>
                                      <WarningIcon color="warning" />
                                    </ListItemIcon>
                                    <ListItemText primary={caseData.enhanced_analysis.defenses} />
                                  </ListItem>
                                )}
                              </List>
                            </>
                          )}
                        </Paper>
                      </Grid>
                    )}
                    
                    {/* Reasoning */}
                    {caseData.enhanced_analysis.reasoning && (
                      <Grid item xs={12}>
                        <Paper elevation={2} sx={{ p: 2 }}>
                          <Typography variant="h6" gutterBottom>
                            AI Reasoning
                          </Typography>
                          <Typography variant="body1">
                            {caseData.enhanced_analysis.reasoning}
                          </Typography>
                        </Paper>
                      </Grid>
                    )}
                    
                    {/* Raw Analysis (fallback) */}
                    {caseData.enhanced_analysis.raw_analysis && (
                      <Grid item xs={12}>
                        <Paper elevation={2} sx={{ p: 2 }}>
                          <Typography variant="h6" gutterBottom>
                            AI Analysis
                          </Typography>
                          <Typography variant="body1" style={{ whiteSpace: 'pre-line' }}>
                            {caseData.enhanced_analysis.raw_analysis}
                          </Typography>
                        </Paper>
                      </Grid>
                    )}
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          )}
        </Grid>

        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography variant="body2" color="text.secondary" paragraph>
            This prediction is based on historical case data and should be used as a reference only.
            Always consult with a qualified legal professional before making decisions.
          </Typography>
          <Button variant="contained" color="primary" href="/">
            Return to Home
          </Button>
        </Box>
      </Box>
    </Container>
  );
};

export default DashboardPage;