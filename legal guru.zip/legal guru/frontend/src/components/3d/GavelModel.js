import React, { useRef } from 'react';

// Use conditional imports to handle both CDN and npm package scenarios
const useFrame = window.R3F ? window.R3F.useFrame : require('@react-three/fiber').useFrame;
const useGLTF = window.DREI ? window.DREI.useGLTF : require('@react-three/drei').useGLTF;
const THREE = window.THREE || require('three');

// Custom 3D Gavel model component
const GavelModel = ({ position = [0, 0, 0], rotation = [0, 0, 0], scale = 0.5 }) => {
  const meshRef = useRef();
  
  // Animate the gavel with a gentle rotation
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.2;
    }
  });

  // Create a simple 3D gavel model using basic Three.js geometries
  return (
    <group position={position} rotation={rotation} scale={scale} ref={meshRef}>
      {/* Gavel head */}
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[0.4, 0.4, 1, 16]} />
        <meshStandardMaterial color="#8B4513" roughness={0.7} metalness={0.2} />
      </mesh>
      
      {/* Gavel handle */}
      <mesh position={[0, -1, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.15, 0.15, 3, 16]} />
        <meshStandardMaterial color="#A0522D" roughness={0.5} metalness={0.1} />
      </mesh>
      
      {/* Gavel base */}
      <mesh position={[0, -2.5, 0]}>
        <boxGeometry args={[1.2, 0.3, 0.8]} />
        <meshStandardMaterial color="#654321" roughness={0.6} metalness={0.1} />
      </mesh>
    </group>
  );
};

export default GavelModel;