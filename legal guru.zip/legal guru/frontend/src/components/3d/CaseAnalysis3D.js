import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

// 3D visualization for case analysis data
const CaseAnalysis3D = ({ caseData, position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 }) => {
  const groupRef = useRef();
  
  // Calculate outcome probability for visualization
  const outcomeProb = caseData?.prediction?.probability || 0.5;
  
  // Animation for the 3D visualization
  useFrame((state) => {
    if (groupRef.current) {
      // Gentle floating animation
      groupRef.current.position.y = position[1] + Math.sin(state.clock.getElapsedTime() * 0.5) * 0.1;
      
      // Subtle rotation
      groupRef.current.rotation.y = rotation[1] + Math.sin(state.clock.getElapsedTime() * 0.3) * 0.05;
    }
  });

  return (
    <group position={position} rotation={rotation} scale={scale} ref={groupRef}>
      {/* Main platform */}
      <RoundedBox args={[4, 0.2, 4]} radius={0.1} smoothness={4} position={[0, -1, 0]}>
        <meshStandardMaterial color="#1a237e" metalness={0.5} roughness={0.2} />
      </RoundedBox>
      
      {/* Outcome visualization - a column that grows based on probability */}
      <group position={[0, 0, 0]}>
        {/* Base */}
        <mesh position={[0, -0.8, 0]}>
          <cylinderGeometry args={[0.8, 1, 0.2, 32]} />
          <meshStandardMaterial color="#424242" metalness={0.7} roughness={0.2} />
        </mesh>
        
        {/* Dynamic column representing outcome probability */}
        <mesh position={[0, outcomeProb * 2 - 0.5, 0]}>
          <cylinderGeometry args={[0.5, 0.5, outcomeProb * 4, 32]} />
          <meshStandardMaterial 
            color={outcomeProb > 0.6 ? '#4caf50' : outcomeProb > 0.4 ? '#ff9800' : '#f44336'}
            metalness={0.5} 
            roughness={0.2} 
            emissive={outcomeProb > 0.6 ? '#4caf50' : outcomeProb > 0.4 ? '#ff9800' : '#f44336'}
            emissiveIntensity={0.5}
          />
        </mesh>
        
        {/* Probability text */}
        <Text
          position={[0, outcomeProb * 2 + 0.5, 0]}
          fontSize={0.3}
          color="white"
          anchorX="center"
          anchorY="middle"
          font="https://fonts.gstatic.com/s/raleway/v14/1Ptrg8zYS_SKggPNwK4vaqI.woff"
        >
          {`${Math.round(outcomeProb * 100)}%`}
        </Text>
        
        {/* Outcome label */}
        <Text
          position={[0, -1.5, 0]}
          fontSize={0.25}
          color="white"
          anchorX="center"
          anchorY="middle"
          font="https://fonts.gstatic.com/s/raleway/v14/1Ptrg8zYS_SKggPNwK4vaqI.woff"
        >
          OUTCOME PROBABILITY
        </Text>
      </group>
      
      {/* Key factors visualization - orbiting spheres */}
      {caseData?.key_factors && caseData.key_factors.slice(0, 5).map((factor, index) => {
        const angle = (index / 5) * Math.PI * 2;
        const radius = 1.8;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const impactColor = factor.impact === 'Positive' ? '#4caf50' : factor.impact === 'Negative' ? '#f44336' : '#ff9800';
        
        return (
          <group key={index} position={[x, 0, z]}>
            {/* Factor sphere */}
            <mesh>
              <sphereGeometry args={[0.2, 16, 16]} />
              <meshStandardMaterial 
                color={impactColor} 
                metalness={0.5} 
                roughness={0.2}
                emissive={impactColor}
                emissiveIntensity={0.3}
              />
            </mesh>
            
            {/* Factor label */}
            <Text
              position={[0, 0.4, 0]}
              fontSize={0.15}
              maxWidth={1}
              color="white"
              anchorX="center"
              anchorY="middle"
              font="https://fonts.gstatic.com/s/raleway/v14/1Ptrg8zYS_SKggPNwK4vaqI.woff"
            >
              {factor.factor.substring(0, 20)}
            </Text>
          </group>
        );
      })}
    </group>
  );
};

export default CaseAnalysis3D;