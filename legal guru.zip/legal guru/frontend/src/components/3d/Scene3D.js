import React, { Suspense } from 'react';

// Safely access global variables or use imports
let Canvas, OrbitControls, Environment, PresentationControls;

// Check if the global variables exist before trying to destructure them
if (typeof window !== 'undefined' && window.R3F) {
  Canvas = window.R3F.Canvas;
} else {
  // Only require if the global isn't available
  const fiber = require('@react-three/fiber');
  Canvas = fiber.Canvas;
}

if (typeof window !== 'undefined' && window.DREI) {
  OrbitControls = window.DREI.OrbitControls;
  Environment = window.DREI.Environment;
  PresentationControls = window.DREI.PresentationControls;
} else {
  // Only require if the global isn't available
  const drei = require('@react-three/drei');
  OrbitControls = drei.OrbitControls;
  Environment = drei.Environment;
  PresentationControls = drei.PresentationControls;
}

// A reusable 3D scene component that can be used throughout the application
const Scene3D = ({ children, cameraPosition = [0, 0, 5], controls = true, background = '#000000', height = '100%', width = '100%' }) => {
  return (
    <Canvas
      camera={{ position: cameraPosition, fov: 45 }}
      style={{ height, width }}
    >
      {/* Add ambient lighting */}
      <ambientLight intensity={0.5} />
      
      {/* Add directional light for shadows */}
      <directionalLight 
        position={[10, 10, 5]} 
        intensity={1} 
        castShadow 
        shadow-mapSize-width={1024} 
        shadow-mapSize-height={1024}
      />
      
      {/* Add a subtle point light for highlights */}
      <pointLight position={[-10, -10, -10]} intensity={0.5} />
      
      {/* Wrap children in Suspense for async loading */}
      <Suspense fallback={null}>
        {/* PresentationControls for limited, user-friendly rotation */}
        <PresentationControls
          global
          snap
          rotation={[0, 0, 0]}
          polar={[-Math.PI / 4, Math.PI / 4]}
          azimuth={[-Math.PI / 4, Math.PI / 4]}
        >
          {children}
        </PresentationControls>
        
        {/* Environment adds realistic lighting */}
        <Environment preset="city" />
      </Suspense>
      
      {/* Add orbit controls if enabled */}
      {controls && <OrbitControls enableZoom={false} enablePan={false} />}
    </Canvas>
  );
};

export default Scene3D;