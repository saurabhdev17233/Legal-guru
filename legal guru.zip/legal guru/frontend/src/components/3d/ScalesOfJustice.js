import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text } from '@react-three/drei';

// 3D Scales of Justice model
const ScalesOfJustice = ({ position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 }) => {
  const groupRef = useRef();
  const leftPanRef = useRef();
  const rightPanRef = useRef();
  
  // State to track the balance of the scales
  const [balance, setBalance] = useState(0);
  
  // Animate the scales with a gentle swaying motion
  useFrame((state) => {
    if (groupRef.current) {
      // Gentle rotation of the entire model
      groupRef.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 0.2) * 0.1;
    }
    
    if (leftPanRef.current && rightPanRef.current) {
      // Calculate the current balance based on time
      const newBalance = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.2;
      setBalance(newBalance);
      
      // Apply the balance to the scale pans
      leftPanRef.current.position.y = -2 - newBalance;
      rightPanRef.current.position.y = -2 + newBalance;
    }
  });

  return (
    <group position={position} rotation={rotation} scale={scale} ref={groupRef}>
      {/* Base */}
      <mesh position={[0, -3, 0]}>
        <cylinderGeometry args={[1, 1.2, 0.3, 32]} />
        <meshStandardMaterial color="#4a4a4a" metalness={0.8} roughness={0.2} />
      </mesh>
      
      {/* Pillar */}
      <mesh position={[0, -1, 0]}>
        <cylinderGeometry args={[0.2, 0.2, 4, 16]} />
        <meshStandardMaterial color="#5a5a5a" metalness={0.7} roughness={0.3} />
      </mesh>
      
      {/* Crossbar */}
      <mesh position={[0, 1, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.1, 0.1, 4, 16]} />
        <meshStandardMaterial color="#6a6a6a" metalness={0.7} roughness={0.3} />
      </mesh>
      
      {/* Left scale pan */}
      <group position={[-1.5, -2, 0]} ref={leftPanRef}>
        <mesh>
          <cylinderGeometry args={[0.6, 0.6, 0.1, 32]} />
          <meshStandardMaterial color="#b8860b" metalness={0.9} roughness={0.1} />
        </mesh>
        <mesh position={[0, 0.2, 0]}>
          <Text
            position={[0, 0, 0.1]}
            rotation={[-Math.PI / 2, 0, 0]}
            fontSize={0.2}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            LAW
          </Text>
        </mesh>
      </group>
      
      {/* Right scale pan */}
      <group position={[1.5, -2, 0]} ref={rightPanRef}>
        <mesh>
          <cylinderGeometry args={[0.6, 0.6, 0.1, 32]} />
          <meshStandardMaterial color="#b8860b" metalness={0.9} roughness={0.1} />
        </mesh>
        <mesh position={[0, 0.2, 0]}>
          <Text
            position={[0, 0, 0.1]}
            rotation={[-Math.PI / 2, 0, 0]}
            fontSize={0.2}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            JUSTICE
          </Text>
        </mesh>
      </group>
      
      {/* Strings for left pan */}
      <mesh position={[-1.5, -1, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 2, 8]} />
        <meshStandardMaterial color="#888888" metalness={0.5} roughness={0.5} />
      </mesh>
      
      {/* Strings for right pan */}
      <mesh position={[1.5, -1, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 2, 8]} />
        <meshStandardMaterial color="#888888" metalness={0.5} roughness={0.5} />
      </mesh>
    </group>
  );
};

export default ScalesOfJustice;