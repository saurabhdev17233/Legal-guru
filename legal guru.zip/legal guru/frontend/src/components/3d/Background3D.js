import React, { useRef } from 'react';
// Use conditional imports to handle both CDN and npm package scenarios
const useFrame = window.R3F ? window.R3F.useFrame : require('@react-three/fiber').useFrame;
const Canvas = window.R3F ? window.R3F.Canvas : require('@react-three/fiber').Canvas;
const Stars = window.DREI ? window.DREI.Stars : require('@react-three/drei').Stars;
const Cloud = window.DREI ? window.DREI.Cloud : require('@react-three/drei').Cloud;
const THREE = window.THREE || require('three');

// Floating document component
const FloatingDocument = ({ position, rotation, scale = 1 }) => {
  const meshRef = useRef();
  
  // Random speed for floating animation
  const speed = useRef(Math.random() * 0.2 + 0.1);
  const initialY = useRef(position[1]);
  
  useFrame((state) => {
    if (meshRef.current) {
      // Floating animation
      meshRef.current.position.y = initialY.current + Math.sin(state.clock.getElapsedTime() * speed.current) * 0.3;
      
      // Gentle rotation
      meshRef.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.2) * 0.05;
      meshRef.current.rotation.y += 0.001;
    }
  });

  return (
    <group position={position} rotation={rotation} ref={meshRef}>
      {/* Document base */}
      <mesh>
        <boxGeometry args={[1 * scale, 1.4 * scale, 0.05 * scale]} />
        <meshStandardMaterial color="#f5f5f5" roughness={0.2} />
      </mesh>
      
      {/* Document lines */}
      {[...Array(8)].map((_, i) => (
        <mesh key={i} position={[0, 0.5 - i * 0.15 * scale, 0.03]}>
          <boxGeometry args={[0.8 * scale, 0.03 * scale, 0.01 * scale]} />
          <meshStandardMaterial color="#aaaaaa" />
        </mesh>
      ))}
    </group>
  );
};

// Floating paragraph symbol
const ParagraphSymbol = ({ position, rotation, scale = 1 }) => {
  const meshRef = useRef();
  
  // Random speed for floating animation
  const speed = useRef(Math.random() * 0.2 + 0.1);
  const initialY = useRef(position[1]);
  
  useFrame((state) => {
    if (meshRef.current) {
      // Floating animation
      meshRef.current.position.y = initialY.current + Math.sin(state.clock.getElapsedTime() * speed.current) * 0.3;
      
      // Gentle rotation
      meshRef.current.rotation.z = Math.sin(state.clock.getElapsedTime() * 0.3) * 0.1;
      meshRef.current.rotation.y += 0.002;
    }
  });

  return (
    <group position={position} rotation={rotation} ref={meshRef}>
      {/* Paragraph symbol */}
      <mesh>
        <cylinderGeometry args={[0.1 * scale, 0.1 * scale, 0.6 * scale, 16]} />
        <meshStandardMaterial color="#b8860b" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[0, -0.2 * scale, 0]}>
        <sphereGeometry args={[0.15 * scale, 16, 16]} />
        <meshStandardMaterial color="#b8860b" metalness={0.8} roughness={0.2} />
      </mesh>
    </group>
  );
};

// Main background component
const Background3D = ({ height = '100vh' }) => {
  return (
    <div style={{ 
      position: 'absolute', 
      top: 0, 
      left: 0, 
      width: '100%', 
      height: height, 
      zIndex: -1,
      overflow: 'hidden',
      pointerEvents: 'none',
    }}>
      <Canvas camera={{ position: [0, 0, 15], fov: 60 }}>
        {/* Ambient light */}
        <ambientLight intensity={0.2} />
        
        {/* Directional light */}
        <directionalLight position={[5, 5, 5]} intensity={0.5} />
        
        {/* Stars background */}
        <Stars radius={100} depth={50} count={1000} factor={4} saturation={0} fade speed={1} />
        
        {/* Clouds */}
        <Cloud position={[-4, -2, -10]} speed={0.2} opacity={0.4} width={10} depth={1.5} segments={20} />
        <Cloud position={[4, 2, -15]} speed={0.1} opacity={0.3} width={10} depth={2} segments={20} />
        
        {/* Floating documents */}
        <FloatingDocument position={[-5, 2, -5]} rotation={[0.2, 0.5, 0.1]} scale={0.8} />
        <FloatingDocument position={[4, -1, -8]} rotation={[-0.3, -0.2, 0.1]} scale={1.2} />
        <FloatingDocument position={[-3, -3, -6]} rotation={[0.1, 0.3, -0.2]} scale={0.7} />
        <FloatingDocument position={[5, 3, -10]} rotation={[-0.2, 0.4, 0.3]} scale={1} />
        
        {/* Paragraph symbols */}
        <ParagraphSymbol position={[-2, 0, -4]} rotation={[0, 0, 0]} scale={1} />
        <ParagraphSymbol position={[3, 2, -7]} rotation={[0, 0, 0]} scale={1.2} />
        <ParagraphSymbol position={[0, -2, -5]} rotation={[0, 0, 0]} scale={0.8} />
      </Canvas>
    </div>
  );
};

export default Background3D;