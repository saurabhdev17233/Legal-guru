import React, { useState, useEffect } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import { styled } from '@mui/material/styles';

// Import 3D components with dynamic loading to handle both CDN and local package scenarios
const Scene3D = React.lazy(() => import('./Scene3D'));
const GavelModel = React.lazy(() => import('./GavelModel'));

// Styled components for 3D-enhanced header
const StyledAppBar = styled(AppBar)(({ theme }) => ({
  background: 'linear-gradient(135deg, #1a237e 0%, #283593 50%, #303f9f 100%)',
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.25)',
  position: 'relative',
  overflow: 'hidden',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%)',
    pointerEvents: 'none',
  }
}));

const GlowingText = styled(Typography)(({ theme }) => ({
  color: '#ffffff',
  textShadow: '0 0 10px rgba(255,255,255,0.5), 0 0 20px rgba(255,255,255,0.3)',
  fontWeight: 'bold',
  transition: 'all 0.3s ease',
  '&:hover': {
    textShadow: '0 0 15px rgba(255,255,255,0.8), 0 0 30px rgba(255,255,255,0.5)',
  }
}));

const AnimatedButton = styled(Button)(({ theme }) => ({
  position: 'relative',
  overflow: 'hidden',
  transition: 'all 0.3s ease',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '-100%',
    width: '100%',
    height: '100%',
    background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
    transition: 'all 0.5s ease',
  },
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: '0 7px 14px rgba(0,0,0,0.2)',
    '&::before': {
      left: '100%',
    }
  }
}));

const SceneContainer = styled(Box)(({ theme }) => ({
  position: 'absolute',
  top: 0,
  right: 0,
  width: '200px',
  height: '100%',
  pointerEvents: 'none',
  [theme.breakpoints.down('md')]: {
    display: 'none',
  },
}));

const Header3D = () => {
  const [scrolled, setScrolled] = useState(false);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  return (
    <StyledAppBar 
      position="sticky" 
      sx={{
        height: scrolled ? '70px' : '80px',
        transition: 'height 0.3s ease',
      }}
    >
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          {/* Logo and Title */}
          <Box sx={{ display: 'flex', alignItems: 'center', flexGrow: 1 }}>
            <GlowingText
              variant="h5"
              noWrap
              component={RouterLink}
              to="/"
              sx={{
                mr: 2,
                fontFamily: 'monospace',
                fontWeight: 700,
                letterSpacing: '.2rem',
                color: 'inherit',
                textDecoration: 'none',
                fontSize: scrolled ? '1.2rem' : '1.5rem',
                transition: 'font-size 0.3s ease',
              }}
            >
              LEGAL GURU
            </GlowingText>
          </Box>

          {/* Navigation Buttons */}
          <Box sx={{ display: 'flex', gap: 2 }}>
            <AnimatedButton
              component={RouterLink}
              to="/"
              color="inherit"
              sx={{ borderRadius: '8px' }}
            >
              Home
            </AnimatedButton>
            <AnimatedButton
              component={RouterLink}
              to="/analyze"
              color="inherit"
              sx={{ borderRadius: '8px' }}
            >
              Analyze
            </AnimatedButton>
            <AnimatedButton
              component={RouterLink}
              to="/about"
              color="inherit"
              sx={{ borderRadius: '8px' }}
            >
              About
            </AnimatedButton>
          </Box>

          {/* 3D Scene with Gavel */}
          <SceneContainer>
            <React.Suspense fallback={<div />}>
              <Scene3D>
                <GavelModel position={[0, -0.5, 0]} rotation={[0, Math.PI / 4, 0]} />
              </Scene3D>
            </React.Suspense>
          </SceneContainer>
        </Toolbar>
      </Container>
    </StyledAppBar>
  );
};

export default Header3D;