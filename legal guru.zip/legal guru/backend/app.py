import os
import sys
import json
import random
from datetime import datetime
import time
import numpy as np
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Import NLP and ML modules
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics.pairwise import cosine_similarity

# For document processing
from PyPDF2 import PdfReader
import docx

# Import ECHR dataset and prediction model
try:
    # Use relative import path to find the models directory
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    from models.echr_dataset import load_echr_dataset, get_similar_echr_cases
    from models.prediction_model import train_prediction_model, predict_case_outcome
    # Import Groq integration
    from models.groq_integration import generate_legal_strategies, fetch_real_cases, generate_case_analysis
    ECHR_AVAILABLE = True
    GROQ_AVAILABLE = True
    print("ECHR dataset and prediction model loaded successfully")
    print("Groq integration loaded successfully")
except ImportError as e:
    print(f"Warning: ECHR dataset or prediction model not available: {e}")
    ECHR_AVAILABLE = False
    GROQ_AVAILABLE = False

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Create directories for storing uploaded files and processed data
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'uploads')
PROCESSED_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'processed')

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_FOLDER, exist_ok=True)

# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

# Load ECHR dataset if available
ECHR_CASES = []
if ECHR_AVAILABLE:
    try:
        print("Loading ECHR dataset...")
        ECHR_CASES = load_echr_dataset(max_cases=200)  # Limit to 200 cases for performance
        print(f"Loaded {len(ECHR_CASES)} ECHR cases")
        
        # Train prediction model in background
        print("Training prediction model in background...")
        import threading
        def train_model_thread():
            try:
                train_prediction_model()
                print("Prediction model training completed")
            except Exception as e:
                print(f"Error training prediction model: {e}")
        
        threading.Thread(target=train_model_thread).start()
    except Exception as e:
        print(f"Error loading ECHR dataset: {e}")

# Combine ECHR cases with mock cases
ALL_CASES = ECHR_CASES.copy()

# Check if Groq API key is available
# Check if Groq API key is available
try:
    from models.groq_integration import get_api_key
    try:
        get_api_key()  # This will use the environment variable or fallback
        print("Groq API key found, Groq integration enabled")
        USE_GROQ = True
        GROQ_AVAILABLE = True
    except ValueError:
        print("Groq API key not found, using fallback methods")
        USE_GROQ = False
        GROQ_AVAILABLE = False
except Exception as e:
    print(f"Error initializing Groq integration: {e}")
    USE_GROQ = False
    GROQ_AVAILABLE = False

# Mock database of previous cases for similarity comparison
MOCK_CASES = [
    {
        "id": "case001",
        "title": "Smith v. Johnson",
        "facts": "Plaintiff alleges breach of contract for failure to deliver goods as specified in agreement dated January 15, 2022.",
        "jurisdiction": "Federal",
        "citations": ["Brown v. Davis, 2020", "Commercial Code §2-601"],
        "outcome": "Plaintiff prevailed",
        "damages": "$125,000",
        "reasoning": "Clear evidence of breach with no mitigating circumstances."
    },
    {
        "id": "case002",
        "title": "Williams v. City of Springfield",
        "facts": "Plaintiff claims wrongful termination based on age discrimination following 15 years of employment.",
        "jurisdiction": "State",
        "citations": ["Age Discrimination in Employment Act", "Taylor v. Metro Corp., 2019"],
        "outcome": "Defendant prevailed",
        "damages": "None",
        "reasoning": "Insufficient evidence of discriminatory intent; documented performance issues."
    },
    {
        "id": "case003",
        "title": "Garcia v. ABC Insurance",
        "facts": "Plaintiff seeks coverage for property damage following hurricane. Insurer denied claim citing policy exclusions.",
        "jurisdiction": "State",
        "citations": ["Insurance Code §553.155", "Rodriguez v. National Insurance, 2021"],
        "outcome": "Plaintiff partially prevailed",
        "damages": "$45,000",
        "reasoning": "Some damages covered under policy; others properly excluded."
    },
    {
        "id": "case004",
        "title": "United States v. Thompson",
        "facts": "Defendant charged with wire fraud related to investment scheme targeting elderly victims.",
        "jurisdiction": "Federal",
        "citations": ["18 U.S.C. § 1343", "United States v. Wilson, 2018"],
        "outcome": "Defendant convicted",
        "damages": "Restitution of $1.2M, 8 years imprisonment",
        "reasoning": "Overwhelming evidence of intentional misrepresentation and fraudulent intent."
    },
    {
        "id": "case005",
        "title": "Lee v. Memorial Hospital",
        "facts": "Medical malpractice claim alleging surgical error resulting in permanent nerve damage.",
        "jurisdiction": "State",
        "citations": ["Medical Malpractice Act §5.2", "Rivera v. General Hospital, 2017"],
        "outcome": "Settlement",
        "damages": "$750,000",
        "reasoning": "Evidence of deviation from standard of care; settled before trial."
    }
]

# Function to extract text from PDF
def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, 'rb') as file:
        pdf_reader = PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text

# Function to extract text from DOCX
def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    text = []
    for para in doc.paragraphs:
        text.append(para.text)
    return '\n'.join(text)

# Function to extract key information from text
def extract_case_info(text):
    # In a real system, this would use NLP to extract structured information
    # For the prototype, we'll use a simplified approach
    
    # Tokenize the text
    tokens = word_tokenize(text.lower())
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [w for w in tokens if w not in stop_words]
    
    # Extract potential facts (simplified)
    facts = text[:500] + "..." if len(text) > 500 else text
    
    # Extract potential citations (simplified - look for v. pattern)
    citations = []
    for i in range(len(tokens) - 2):
        if tokens[i+1] == 'v.' and tokens[i].isalpha() and tokens[i+2].isalpha():
            citation = f"{tokens[i].capitalize()} v. {tokens[i+2].capitalize()}"
            if citation not in citations:
                citations.append(citation)
    
    # Determine jurisdiction (simplified)
    jurisdiction = "Federal" if "federal" in text.lower() or "u.s." in text.lower() else "State"
    
    return {
        "facts": facts,
        "citations": citations,
        "jurisdiction": jurisdiction
    }

# Function to find similar cases
def find_similar_cases(case_info):
    # In a real system, this would use embeddings or more sophisticated similarity measures
    # For the prototype, we'll use TF-IDF and cosine similarity
    
    # Try to get real cases from Groq if available
    groq_similar_cases = []
    if USE_GROQ and GROQ_AVAILABLE:
        try:
            print("Fetching real cases from Groq...")
            jurisdiction = case_info.get("jurisdiction", "")
            groq_similar_cases = fetch_real_cases(case_info["facts"], jurisdiction, limit=3)
            print(f"Fetched {len(groq_similar_cases)} real cases from Groq")
        except Exception as e:
            print(f"Error fetching real cases from Groq: {e}")
    
    # Get similar cases from ECHR dataset if available
    echr_similar_cases = []
    if ECHR_AVAILABLE and ECHR_CASES:
        try:
            echr_similar_cases = get_similar_echr_cases(case_info["facts"], ECHR_CASES, top_n=3)
            # Add similarity score for display
            for case in echr_similar_cases:
                case["similarity"] = round(random.uniform(0.65, 0.95), 2)  # Mock similarity score
        except Exception as e:
            print(f"Error finding similar ECHR cases: {e}")
    
    # Also find similar cases from mock database
    # Create corpus of case facts
    corpus = [case["facts"] for case in MOCK_CASES]
    corpus.append(case_info["facts"])
    
    # Create TF-IDF vectors
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(corpus)
    
    # Calculate similarity between the new case and existing cases
    query_vector = tfidf_matrix[-1]
    similarities = cosine_similarity(query_vector, tfidf_matrix[:-1])[0]
    
    # Get top 3 similar cases
    similar_indices = similarities.argsort()[-3:][::-1]
    mock_similar_cases = [MOCK_CASES[i] for i in similar_indices if similarities[i] > 0.1]
    
    # Add similarity score for display
    for i, case in enumerate(mock_similar_cases):
        case["similarity"] = round(similarities[similar_indices[i]], 2)
    
    # Combine and return top cases
    combined_cases = groq_similar_cases + echr_similar_cases + mock_similar_cases
    combined_cases.sort(key=lambda x: x.get("similarity", 0), reverse=True)
    
    return combined_cases[:5]  # Return top 5 most similar cases

# Function to predict case outcome
def predict_outcome(case_info, similar_cases):
    # Try to use the ML model if available
    ml_prediction = None
    if ECHR_AVAILABLE:
        try:
            ml_result = predict_case_outcome(case_info["facts"])
            ml_prediction = ml_result["prediction"]
            ml_confidence = ml_result["confidence"]
            ml_explanation = ml_result["explanation"]
        except Exception as e:
            print(f"Error using ML prediction model: {e}")
    
    # If no similar cases and no ML prediction, return a random prediction
    if not similar_cases and not ml_prediction:
        outcomes = ["Plaintiff likely to prevail", "Defendant likely to prevail", "Likely settlement"]
        return {
            "prediction": random.choice(outcomes),
            "confidence": round(random.uniform(0.5, 0.65), 2),
            "explanation": "Insufficient similar cases for reliable prediction."
        }
    
    # If we have an ML prediction but no similar cases
    if ml_prediction and not similar_cases:
        return {
            "prediction": ml_prediction,
            "confidence": ml_confidence,
            "explanation": ml_explanation + " No similar cases found in database."
        }
    
    # Count outcomes in similar cases
    outcome_counts = {}
    for case in similar_cases:
        outcome = case["outcome"]
        if outcome in outcome_counts:
            outcome_counts[outcome] += 1
        else:
            outcome_counts[outcome] = 1
    
    # Determine most likely outcome from similar cases
    most_common_outcome = max(outcome_counts, key=outcome_counts.get)
    similarity_confidence = round(outcome_counts[most_common_outcome] / len(similar_cases), 2)
    
    # Map to simplified prediction
    if "plaintiff prevailed" in most_common_outcome.lower() or "violation found" in most_common_outcome.lower():
        similarity_prediction = "Plaintiff likely to prevail"
    elif "defendant prevailed" in most_common_outcome.lower() or "no violation found" in most_common_outcome.lower():
        similarity_prediction = "Defendant likely to prevail"
    elif "settlement" in most_common_outcome.lower():
        similarity_prediction = "Likely settlement"
    elif "convicted" in most_common_outcome.lower():
        similarity_prediction = "Conviction likely"
    else:
        similarity_prediction = most_common_outcome
    
    # Generate explanation based on similar cases
    similarity_explanation = f"Based on {len(similar_cases)} similar cases, the most common outcome was {most_common_outcome}."
    
    # If we have both ML and similarity predictions, combine them
    if ml_prediction:
        # If predictions agree, increase confidence
        if ml_prediction == similarity_prediction:
            final_confidence = round((ml_confidence + similarity_confidence) / 2 + 0.1, 2)
            final_confidence = min(final_confidence, 0.95)  # Cap at 0.95
            final_explanation = f"{ml_explanation} This is supported by similar case analysis: {similarity_explanation}"
            return {
                "prediction": ml_prediction,
                "confidence": final_confidence,
                "explanation": final_explanation
            }
        else:
            # If predictions disagree, go with the ML model but lower confidence
            final_confidence = round(ml_confidence * 0.8, 2)
            final_explanation = f"{ml_explanation} However, similar case analysis suggests a different outcome: {similarity_explanation}"
            return {
                "prediction": ml_prediction,
                "confidence": final_confidence,
                "explanation": final_explanation
            }
    
    # If no ML prediction, use similarity-based prediction
    return {
        "prediction": similarity_prediction,
        "confidence": similarity_confidence + random.uniform(0.1, 0.2),  # Add randomness for demo
        "explanation": similarity_explanation
    }

# Function to generate strategy suggestions
def generate_strategy(case_info, prediction, similar_cases):
    # Try to use Groq for strategy generation if available
    if USE_GROQ and GROQ_AVAILABLE:
        try:
            print("Generating strategies using Groq...")
            groq_strategies = generate_legal_strategies(case_info["facts"], similar_cases, prediction)
            if groq_strategies:
                print(f"Generated {len(groq_strategies)} strategies using Groq")
                return groq_strategies
        except Exception as e:
            print(f"Error generating strategies using Groq: {e}")
    
    # Fallback to template-based approach
    print("Using template-based strategy generation")
    strategies = []
    
    # Based on jurisdiction
    if case_info["jurisdiction"] == "Federal":
        strategies.append("Consider procedural differences in federal court, including stricter discovery timelines.")
    else:
        strategies.append("State court procedures may allow for more flexible case management.")
    
    # Based on prediction
    if "plaintiff likely" in prediction["prediction"].lower():
        strategies.append("Focus on damages calculation and documentation to maximize recovery.")
        strategies.append("Consider early settlement discussions from a position of strength.")
    elif "defendant likely" in prediction["prediction"].lower():
        strategies.append("Develop strong defensive arguments and consider motion for summary judgment.")
        strategies.append("Evaluate cost-benefit of proceeding to trial versus settlement.")
    elif "settlement" in prediction["prediction"].lower():
        strategies.append("Prepare settlement proposal with favorable terms.")
        strategies.append("Identify key leverage points for negotiation.")
    
    # Based on similar cases
    if similar_cases:
        citations_from_similar = []
        for case in similar_cases:
            citations_from_similar.extend(case.get("citations", []))
        
        if citations_from_similar:
            most_cited = max(set(citations_from_similar), key=citations_from_similar.count)
            strategies.append(f"Research and leverage precedent from {most_cited} which was cited in similar cases.")
    
    return strategies

# API Routes
@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    # Create a unique filename
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filename = f"{timestamp}_{file.filename}"
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    
    # Save the file
    file.save(file_path)
    
    # Process the file based on its type
    try:
        if file.filename.lower().endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        elif file.filename.lower().endswith('.docx'):
            text = extract_text_from_docx(file_path)
        elif file.filename.lower().endswith('.txt'):
            # For text files, just read the content directly
            with open(file_path, 'r', encoding='utf-8') as txt_file:
                text = txt_file.read()
        else:
            return jsonify({"error": "Unsupported file format"}), 400
        
        # Extract case information
        case_info = extract_case_info(text)
        
        # Save processed data
        processed_file = os.path.join(PROCESSED_FOLDER, f"{timestamp}_processed.json")
        with open(processed_file, 'w') as f:
            json.dump(case_info, f)
        
        # Find similar cases
        similar_cases = find_similar_cases(case_info)
        
        # Predict outcome
        prediction = predict_outcome(case_info, similar_cases)
        
        # Generate strategy suggestions
        strategies = generate_strategy(case_info, prediction, similar_cases)
        
        # Simulate processing time for demo purposes
        time.sleep(2)
        
        return jsonify({
            "id": timestamp,
            "filename": file.filename,
            "case_info": case_info,
            "similar_cases": similar_cases,
            "prediction": prediction,
            "strategies": strategies
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/form', methods=['POST'])
def process_form():
    try:
        # Get form data
        data = request.json
        
        # Extract case information from form data
        case_info = {
            "facts": data.get("facts", ""),
            "citations": data.get("citations", []),
            "jurisdiction": data.get("jurisdiction", "State")
        }
        
        # Create a unique ID
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Save processed data
        processed_file = os.path.join(PROCESSED_FOLDER, f"{timestamp}_processed.json")
        with open(processed_file, 'w') as f:
            json.dump(case_info, f)
        
        # Find similar cases
        similar_cases = find_similar_cases(case_info)
        
        # Predict outcome
        prediction = predict_outcome(case_info, similar_cases)
        
        # Generate strategy suggestions
        strategies = generate_strategy(case_info, prediction, similar_cases)
        
        # Simulate processing time for demo purposes
        time.sleep(1.5)
        
        return jsonify({
            "id": timestamp,
            "case_info": case_info,
            "similar_cases": similar_cases,
            "prediction": prediction,
            "strategies": strategies
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/cases', methods=['GET'])
def get_cases():
    # In a real system, this would fetch from a database
    # For the prototype, we'll return the combined cases
    # Get query parameter for case type
    case_type = request.args.get('type', 'all')
    
    if case_type == 'echr' and ECHR_CASES:
        # Return only ECHR cases (limited to 20 for performance)
        return jsonify(ECHR_CASES[:20])
    elif case_type == 'mock':
        # Return only mock cases
        return jsonify(MOCK_CASES)
    else:
        # Return combined cases (limited to avoid overwhelming response)
        combined = MOCK_CASES + (ECHR_CASES[:10] if ECHR_CASES else [])
        return jsonify(combined)

@app.route('/api/files/<path:filename>', methods=['GET'])
def get_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

# Add a new endpoint to get case data by ID
@app.route('/api/case/<case_id>', methods=['GET'])
def get_case_by_id(case_id):
    try:
        # Look for the processed file with this ID
        processed_file = os.path.join(PROCESSED_FOLDER, f"{case_id}_processed.json")
        
        if not os.path.exists(processed_file):
            return jsonify({"error": f"No case found with ID {case_id}"}), 404
        
        # Load the processed data
        with open(processed_file, 'r') as f:
            case_info = json.load(f)
        
        # Find similar cases
        similar_cases = find_similar_cases(case_info)
        
        # Predict outcome
        prediction = predict_outcome(case_info, similar_cases)
        
        # Generate strategy suggestions
        strategies = generate_strategy(case_info, prediction, similar_cases)
        
        # Get the original filename if available
        filename = case_id
        for file in os.listdir(UPLOAD_FOLDER):
            if file.startswith(case_id):
                filename = file.replace(f"{case_id}_", "")
                break
        
        # Try to get enhanced analysis from Groq if available
        enhanced_analysis = {}
        if USE_GROQ and GROQ_AVAILABLE:
            try:
                print("Generating enhanced case analysis using Groq...")
                enhanced_analysis = generate_case_analysis(case_info["facts"])
                print("Generated enhanced case analysis using Groq")
            except Exception as e:
                print(f"Error generating enhanced case analysis: {e}")
        
        response_data = {
            "id": case_id,
            "filename": filename,
            "case_info": case_info,
            "similar_cases": similar_cases,
            "prediction": prediction,
            "strategies": strategies
        }
        
        # Add enhanced analysis if available
        if enhanced_analysis and not "error" in enhanced_analysis:
            response_data["enhanced_analysis"] = enhanced_analysis
        
        return jsonify(response_data)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)