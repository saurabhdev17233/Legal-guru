# Models package initialization

# Import main functions for easier access
from models.echr_dataset import load_echr_dataset, get_similar_echr_cases, get_cases_by_article
from models.prediction_model import train_prediction_model, predict_case_outcome