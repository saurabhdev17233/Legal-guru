import os
import pickle
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

# Import the ECHR dataset loader
from models.echr_dataset import load_echr_dataset

# Directory for saving trained models
MODEL_DIR = os.path.dirname(os.path.abspath(__file__))
os.makedirs(MODEL_DIR, exist_ok=True)

# Path to save the trained model
MODEL_PATH = os.path.join(MODEL_DIR, 'echr_prediction_model.pkl')

def train_prediction_model(force_retrain=False, max_cases=500):
    """
    Train a machine learning model to predict case outcomes based on ECHR data.
    
    Args:
        force_retrain: Whether to force retraining even if a saved model exists
        max_cases: Maximum number of cases to use for training
        
    Returns:
        Trained scikit-learn pipeline for prediction
    """
    # Check if model already exists and should be used
    if not force_retrain and os.path.exists(MODEL_PATH):
        print(f"Loading existing prediction model from {MODEL_PATH}")
        with open(MODEL_PATH, 'rb') as f:
            return pickle.load(f)
    
    print("Training new prediction model...")
    # Load ECHR cases
    echr_cases = load_echr_dataset(max_cases=max_cases)
    
    if not echr_cases:
        raise ValueError("No ECHR cases available for training")
    
    # Prepare training data
    X = [case["facts"] for case in echr_cases]
    y = [1 if "Violation found" in case["outcome"] else 0 for case in echr_cases]
    
    # Split into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Create and train the model pipeline
    model = Pipeline([
        ('tfidf', TfidfVectorizer(max_features=5000)),
        ('clf', RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    
    model.fit(X_train, y_train)
    
    # Evaluate on validation set
    y_pred = model.predict(X_val)
    accuracy = accuracy_score(y_val, y_pred)
    print(f"Model accuracy: {accuracy:.2f}")
    print("\nClassification Report:")
    print(classification_report(y_val, y_pred, target_names=["No Violation", "Violation"]))
    
    # Save the trained model
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(model, f)
    
    print(f"Model saved to {MODEL_PATH}")
    return model

def predict_case_outcome(case_text, model=None):
    """
    Predict the outcome of a case based on its text.
    
    Args:
        case_text: The text of the case to predict
        model: Optional pre-loaded model (if None, will load from file)
        
    Returns:
        Dictionary with prediction results
    """
    if model is None:
        # Load the model if not provided
        if os.path.exists(MODEL_PATH):
            with open(MODEL_PATH, 'rb') as f:
                model = pickle.load(f)
        else:
            # Train a new model if none exists
            model = train_prediction_model()
    
    # Make prediction
    violation_prob = model.predict_proba([case_text])[0][1]
    
    # Determine prediction and confidence
    if violation_prob > 0.5:
        prediction = "Plaintiff likely to prevail"
        confidence = violation_prob
    else:
        prediction = "Defendant likely to prevail"
        confidence = 1 - violation_prob
    
    # Generate explanation
    if violation_prob > 0.8:
        explanation = "High probability of finding a violation based on ECHR case patterns."
    elif violation_prob > 0.5:
        explanation = "Moderate probability of finding a violation based on ECHR case patterns."
    elif violation_prob > 0.2:
        explanation = "Moderate probability of finding no violation based on ECHR case patterns."
    else:
        explanation = "High probability of finding no violation based on ECHR case patterns."
    
    return {
        "prediction": prediction,
        "confidence": round(confidence, 2),
        "explanation": explanation,
        "raw_probability": round(violation_prob, 2)
    }

# If run directly, train and save the model
if __name__ == "__main__":
    model = train_prediction_model(force_retrain=True)
    
    # Test with a sample case
    sample_text = """The applicant was detained for 5 years without trial. 
    During this period, he was not allowed to communicate with his family or legal counsel.
    The government claims this was necessary for national security reasons."""
    
    result = predict_case_outcome(sample_text, model)
    print("\nSample Prediction:")
    print(f"Text: {sample_text}")
    print(f"Prediction: {result['prediction']}")
    print(f"Confidence: {result['confidence']}")
    print(f"Explanation: {result['explanation']}")