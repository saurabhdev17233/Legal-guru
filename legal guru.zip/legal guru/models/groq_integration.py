import os
import json
import requests
from typing import List, Dict, Any, Optional

# Groq API base URL
GROQ_API_URL = "https://api.groq.com/openai/v1"

# Default model to use
DEFAULT_MODEL = "llama3-70b-8192"

# Get API key from environment variable or use hardcoded key for testing
def get_api_key() -> str:
    """Get Groq API key from environment variable or use hardcoded key for testing"""
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        print("Using hardcoded Groq API key for testing")
        api_key = "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"
    if not api_key:
        raise ValueError("GROQ_API_KEY environment variable not set and no fallback key available")
    return api_key

def generate_completion(prompt: str, model: str = DEFAULT_MODEL, max_tokens: int = 1000, temperature: float = 0.7) -> Dict[str, Any]:
    """Generate completion using Groq API"""
    try:
        headers = {
            "Authorization": f"Bearer {get_api_key()}",
            "Content-Type": "application/json"
        }
        data = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        response = requests.post(
            f"{GROQ_API_URL}/chat/completions",
            headers=headers,
            json=data
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"Error generating completion: {e}")
        return {"error": str(e)}

def generate_legal_strategies(case_facts: str, similar_cases: List[Dict[str, Any]]) -> List[str]:
    """Generate unbiased legal strategies using Groq AI"""
    similar_cases_text = "\n".join([
        f"- {case['title']}: {case['outcome']} (Similarity: {case['similarity']:.0%})"
        for case in similar_cases[:3]
    ])
    prompt = f"""As a legal expert, provide strategic recommendations for the following case:

CASE FACTS:
{case_facts}

SIMILAR CASES:
{similar_cases_text}

Provide 5 specific, actionable legal strategies that could strengthen the case. Focus on legal best practices, procedural moves, evidentiary considerations, and tactics informed by the case facts and precedent. Avoid any reference to predicted outcomes or confidence levels."""
    try:
        response = generate_completion(prompt)
        if "error" in response:
            return ["Unable to generate strategies using AI", "Please consult with a legal professional"]

        content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
        strategies = []
        for line in content.split("\n"):
            line = line.strip()
            if line and (line.startswith("-") or line.startswith("*") or line[0].isdigit()):
                clean_line = line.lstrip("-*0123456789. ").strip()
                if clean_line:
                    strategies.append(clean_line)
        return strategies[:5] if strategies else [content]
    except Exception as e:
        print(f"Error generating legal strategies: {e}")
        return ["Error generating AI strategies", "Please try again later"]

def fetch_real_cases(query: str, jurisdiction: str = None, limit: int = 5) -> List[Dict[str, Any]]:
    """Fetch real cases using Groq AI"""
    jurisdiction_text = f" in {jurisdiction} jurisdiction" if jurisdiction else ""
    prompt = f"""Find {limit} real legal cases similar to the following case{jurisdiction_text}:

{query}

For each case, provide the following information in a structured format:
- Case title
- Jurisdiction
- Year
- Key facts
- Outcome
- Reasoning

Format your response as a JSON array of case objects with the fields: title, jurisdiction, year, facts, outcome, reasoning."""
    try:
        response = generate_completion(prompt, max_tokens=2000)
        if "error" in response:
            return []

        content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
        try:
            start_idx = content.find("[")
            end_idx = content.rfind("]")
            if start_idx >= 0 and end_idx > start_idx:
                json_str = content[start_idx:end_idx+1]
                cases = json.loads(json_str)
                for i, case in enumerate(cases):
                    case["id"] = f"groq-{i+1}"
                    case["similarity"] = 0.9 - (i * 0.05)
                return cases[:limit]
        except json.JSONDecodeError:
            cases = []
            current_case = {}
            for line in content.split("\n"):
                line = line.strip()
                if not line:
                    continue
                if line.startswith("Case") and "title" in line.lower():
                    if current_case and "title" in current_case:
                        cases.append(current_case)
                    current_case = {"id": f"groq-{len(cases)+1}"}
                    current_case["title"] = line.split(":", 1)[1].strip() if ":" in line else line
                elif ":" in line:
                    key, value = line.split(":", 1)
                    key = key.strip().lower()
                    value = value.strip()
                    if "jurisdiction" in key:
                        current_case["jurisdiction"] = value
                    elif "year" in key:
                        current_case["year"] = value
                    elif "facts" in key or "key facts" in key:
                        current_case["facts"] = value
                    elif "outcome" in key:
                        current_case["outcome"] = value
                    elif "reasoning" in key:
                        current_case["reasoning"] = value
            if current_case and "title" in current_case:
                cases.append(current_case)
            for i, case in enumerate(cases):
                case["similarity"] = 0.9 - (i * 0.05)
            return cases[:limit]
    except Exception as e:
        print(f"Error fetching real cases: {e}")
        return []

def generate_case_analysis(case_facts: str) -> Dict[str, Any]:
    """Generate comprehensive case analysis using Groq AI"""
    prompt = f"""Provide a comprehensive legal analysis of the following case:

{case_facts}

Include the following in your analysis:
1. Key legal issues identified
2. Potential claims and defenses
3. Likely outcome prediction with confidence level
4. Reasoning for the prediction
5. Potential risks and challenges

Format your response as a JSON object with the fields: issues, claims, defenses, prediction, confidence, reasoning, risks."""
    try:
        response = generate_completion(prompt, max_tokens=2000)
        if "error" in response:
            return {"error": response["error"]}
        content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
        try:
            start_idx = content.find("{")
            end_idx = content.rfind("}")
            if start_idx >= 0 and end_idx > start_idx:
                json_str = content[start_idx:end_idx+1]
                analysis = json.loads(json_str)
                return analysis
        except json.JSONDecodeError:
            return {"raw_analysis": content}
    except Exception as e:
        print(f"Error generating case analysis: {e}")
        return {"error": str(e)}