import os
import json
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Directory for caching processed ECHR cases
PROCESSED_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'processed')
os.makedirs(PROCESSED_FOLDER, exist_ok=True)

# Cache file for processed ECHR cases
ECHR_CACHE_FILE = os.path.join(PROCESSED_FOLDER, 'echr_cases.json')

# Mock ECHR dataset for demonstration purposes
MOCK_ECHR_CASES = [
    {
        "id": "001-123456",
        "title": "Smith v. United Kingdom",
        "facts": "The applicant, a British citizen, alleged that his right to a fair trial was violated when he was denied access to legal representation during police questioning. The police claimed that the delay was necessary for the investigation.",
        "outcome": "Violation found",
        "articles": ["Article 6"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2020-01-15",
        "case_type": "Human Rights"
    },
    {
        "id": "001-123457",
        "title": "Johnson v. France",
        "facts": "The applicant claimed that her freedom of expression was restricted when she was fined for publishing critical comments about a public official. The government argued that the comments were defamatory.",
        "outcome": "Violation found",
        "articles": ["Article 10"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2019-06-22",
        "case_type": "Human Rights"
    },
    {
        "id": "001-123458",
        "title": "Garcia v. Spain",
        "facts": "The applicant alleged that his property was expropriated without adequate compensation, violating his right to peaceful enjoyment of possessions. The government claimed the expropriation was in the public interest and fair compensation was offered.",
        "outcome": "No violation found",
        "articles": ["Article 1 of Protocol 1"],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": "2021-03-10",
        "case_type": "Human Rights"
    }
]

# Generate more mock cases for better training data
for i in range(20):
    violation = random.choice([True, False])
    article = random.choice(["Article 3", "Article 5", "Article 6", "Article 8", "Article 10", "Article 14"])
    MOCK_ECHR_CASES.append({
        "id": f"001-{123459+i}",
        "title": f"Mock Case {i+1}",
        "facts": f"This is a mock case about {article}. " + 
                ("The applicant alleged mistreatment and violation of rights. " if violation else "The applicant claimed rights were violated but evidence was insufficient. ") +
                "The court examined all circumstances of the case.",
        "outcome": "Violation found" if violation else "No violation found",
        "articles": [article],
        "jurisdiction": "ECHR (European Court of Human Rights)",
        "date": f"2022-{random.randint(1,12):02d}-{random.randint(1,28):02d}",
        "case_type": "Human Rights"
    })

def load_echr_dataset(use_cache=True, max_cases=500):
    """
    Load mock ECHR dataset for demonstration purposes.
    
    Args:
        use_cache: Whether to use cached data if available
        max_cases: Maximum number of cases to load (to avoid memory issues)
        
    Returns:
        List of processed ECHR cases in the format compatible with the application
    """
    # Check if cached data exists and should be used
    if use_cache and os.path.exists(ECHR_CACHE_FILE):
        print(f"Loading ECHR cases from cache: {ECHR_CACHE_FILE}")
        with open(ECHR_CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    print("Using mock ECHR dataset for demonstration...")
    
    # Use the mock dataset
    processed_cases = []
    
    # Process mock cases (limit to max_cases)
    for i, case in enumerate(MOCK_ECHR_CASES):
        if i >= max_cases:
            break
        
        # Create a processed case in the format expected by the application
        processed_case = {
            "id": case["id"],
            "title": case["title"],
            "facts": case["facts"],
            "outcome": case["outcome"],
            "articles": case["articles"],
            "jurisdiction": case["jurisdiction"],
            "date": case["date"],
            "case_type": case["case_type"]
        }
        processed_cases.append(processed_case)
    
    # Cache the processed cases
    with open(ECHR_CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(processed_cases, f, indent=2)
    
    return processed_cases

def filter_by_article(cases, article_number):
    """
    Filter ECHR cases by article number.
    
    Args:
        cases: List of ECHR cases
        article_number: Article number to filter by (e.g., "6" for Article 6)
        
    Returns:
        Filtered list of cases
    """
    article_str = f"Article {article_number}"
    return [case for case in cases if any(article_str in article for article in case.get("articles", []))]

# Alias for filter_by_article to maintain compatibility with app.py
def get_cases_by_article(cases, article_number):
    """
    Alias for filter_by_article function.
    
    Args:
        cases: List of ECHR cases
        article_number: Article number to filter by (e.g., "6" for Article 6)
        
    Returns:
        Filtered list of cases
    """
    return filter_by_article(cases, article_number)

def get_similar_echr_cases(query_text, echr_cases, top_n=3):
    """
    Find similar ECHR cases based on the query text.
    
    Args:
        query_text: The text to compare against ECHR cases
        echr_cases: List of ECHR cases
        top_n: Number of similar cases to return
        
    Returns:
        List of similar cases with similarity scores
    """
    if not echr_cases:
        return []
    
    # Extract facts from cases
    case_facts = [case["facts"] for case in echr_cases]
    
    # Create TF-IDF vectorizer
    vectorizer = TfidfVectorizer(stop_words='english')
    
    # Fit and transform the case facts
    tfidf_matrix = vectorizer.fit_transform(case_facts + [query_text])
    
    # Calculate cosine similarity between query and all cases
    query_vector = tfidf_matrix[-1]
    case_vectors = tfidf_matrix[:-1]
    similarities = cosine_similarity(query_vector, case_vectors).flatten()
    
    # Get indices of top similar cases
    similar_indices = similarities.argsort()[-top_n:][::-1]
    
    # Create result with cases and similarity scores
    similar_cases = []
    for idx in similar_indices:
        if similarities[idx] > 0:  # Only include if there's some similarity
            case = echr_cases[idx].copy()
            case["similarity"] = float(similarities[idx])
            similar_cases.append(case)
    
    return similar_cases