import requests
import json
import os

def upload_file():
    # The backend now supports PDF, DOCX, and TXT files
    file_path = 'data/sample_documents/sample_case.txt'
    url = 'http://127.0.0.1:5000/api/upload'
    
    try:
        with open(file_path, 'rb') as f:
            # Use the original filename with .txt extension
            filename = os.path.basename(file_path)
            files = {'file': (filename, f, 'text/plain')}
            response = requests.post(url, files=files)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    upload_file()