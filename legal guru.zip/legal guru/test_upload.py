import requests
import os
import json

# Test cases with different content
test_cases = [
    "The applicant was detained for 5 years without trial. During this period, he was not allowed to communicate with his family or legal counsel.",
    "The defendant was found to have properly followed all procedures and provided evidence of compliance with regulations.",
    "The applicant claimed their property was taken without adequate compensation. The government claimed it was for public interest.",
    "The government provided evidence that the applicant had access to legal counsel throughout the proceedings.",
    "The applicant was subjected to inhuman treatment during detention, including physical abuse and denial of medical care."
]

# Create test files
for i, content in enumerate(test_cases):
    filename = f"test_case_{i+1}.txt"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"\n===== TESTING CASE {i+1} =====\n")
    print(f"Content: {content}")
    
    # Upload the file
    url = "http://127.0.0.1:5000/api/upload"
    files = {'file': (filename, open(filename, 'rb'), 'text/plain')}
    
    response = requests.post(url, files=files)
    
    print(f"Status Code: {response.status_code}")
    
    if response.status_code == 200:
        result = response.json()
        print(f"Prediction: {result['prediction']['prediction']}")
        print(f"Confidence: {result['prediction']['confidence']}")
        print(f"Explanation: {result['prediction']['explanation']}")
        print(f"Number of strategies: {len(result['strategies'])}")
    else:
        print(f"Error: {response.text}")

# Clean up test files
for i in range(len(test_cases)):
    filename = f"test_case_{i+1}.txt"
    if os.path.exists(filename):
        os.remove(filename)